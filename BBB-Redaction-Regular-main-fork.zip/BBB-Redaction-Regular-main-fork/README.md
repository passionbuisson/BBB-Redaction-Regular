# Redaction


110 inclusives glyphs has been added to this font by Marie Godefroy for the first issue of Curseurs, thanks to the guide of Bye Bye Binary on gitlab.com/bye-bye-binary and https://typotheque.genderfluid.space/quni.html The inclusives glyphs can be found only on the version of "Redaction Regular". However, there are others styles like Italic and Bold in each version and the versions 10,20,35,50,70 and 100, also without inclusives glyphs.


# Curseurs

Curseurs https://www.curseurs.be/ is a twice-yearly belgian newspaper that focuses on digital solutions to the GAFAM and other oppressive and invasive propositions.
The Redaction font is used in the newspaper as the main typeface and some glyphs, mainly pictogramms that are used in the newspaper, were later incorporated to Marie Godefroy's fork by Clara Bougon in order to ease the layout process. Two post binary glyphs were also modified to resolve some reading issues.
