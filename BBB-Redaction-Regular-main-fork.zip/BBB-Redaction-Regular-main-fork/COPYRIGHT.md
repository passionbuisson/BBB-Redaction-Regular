Copyright (c) 2023, Titus Kaphar and Reginald Dwayne Betts, Marie Godefroy with Bye Bye Binary's guide, Clara Bougon (for the pictograms)
